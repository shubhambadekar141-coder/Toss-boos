Toss Boss Upgraded Game (Cartoon Version)

Features:
- Cartoon birds with human rider
- Unlockable skins: dragon, unicorn
- Collectible coins
- Shop to buy skins
- Safe bird hurt sounds, flap sounds, coin sounds
- Mobile-ready HTML5 game (use PWA2APK or Kodular to make APK)

Instructions:
1. Open index.html to play in browser.
2. Use tap/click or spacebar to jump/fly.
3. Collect coins and unlock skins.
4. To build APK: upload this folder ZIP to PWA2APK or Kodular.

All graphics/sounds are placeholders; you can replace with your own images/sounds.

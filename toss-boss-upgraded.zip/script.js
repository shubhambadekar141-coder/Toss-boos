// Canvas setup
const canvas=document.getElementById('c');const ctx=canvas.getContext('2d');let DPR=devicePixelRatio||1;
function resize(){canvas.width=Math.floor(canvas.clientWidth*DPR);canvas.height=Math.floor(canvas.clientHeight*DPR);ctx.scale(DPR,DPR)}
resize();window.addEventListener('resize',()=>{DPR=devicePixelRatio||1;resize()})
const W=()=>canvas.clientWidth;const H=()=>canvas.clientHeight;let groundY=()=>H()*0.85;

// Player setup
let player={x:40,y:groundY()-50,vy:0,w:50,h:50,onGround:true,skin:'bird1'};
let gravity=0.9,jumpPower=-16;let obstacles=[],spawnTimer=0;let score=0,speed=4,running=true,coins=0;

// Skins prices (coins)
const skinPrices={'bird1':0,'dragon':100,'unicorn':150};
let ownedSkins={'bird1':true,'dragon':false,'unicorn':false};

function reset(){player.y=groundY()-player.h;player.vy=0;obstacles=[];spawnTimer=0;score=0;coins=0;speed=4;running=true;document.getElementById('restart').classList.add('hidden');document.getElementById('msg').textContent='Toss Boss • Tap to fly'}
reset();

function spawnObstacle(){const h=30+Math.random()*40;obstacles.push({x:W()+40,y:groundY()-h,w:20+Math.random()*30,h:h})}
function spawnCoin(){return {x:W()+50,y:groundY()-100-Math.random()*150,w:20,h:20}}
let coinObjs=[];

function update(){
  if(!running) return;
  player.vy+=gravity;player.y+=player.vy;if(player.y+player.h>=groundY()){player.y=groundY()-player.h;player.vy=0;player.onGround=true}else player.onGround=false;

  spawnTimer-=1;
  if(spawnTimer<=0){spawnObstacle();spawnTimer=60+Math.floor(Math.random()*60)-Math.floor(score/100);if(spawnTimer<30) spawnTimer=30}
  for(let i=obstacles.length-1;i>=0;i--){obstacles[i].x-=speed;if(obstacles[i].x+obstacles[i].w<0){obstacles.splice(i,1);score+=10;if(score%100===0) speed+=0.5}}

  // Coins
  if(Math.random()<0.01){coinObjs.push(spawnCoin())}
  for(let i=coinObjs.length-1;i>=0;i--){coinObjs[i].x-=speed;if(coinObjs[i].x<0) coinObjs.splice(i,1);else if(rectIntersect(player,coinObjs[i])){coins+=10;coinObjs.splice(i,1);playSound('coin.mp3')}}

  for(let ob of obstacles){if(rectIntersect(player,ob)){playSound('bird_hurt.mp3');gameOver()}};
  document.getElementById('score').textContent='Score: '+score+' • Coins: '+coins;
}

function rectIntersect(a,b){return!(a.x>b.x+b.w||a.x+a.w<b.x||a.y>b.y+b.h||a.y+a.h<b.y)}
function draw(){ctx.clearRect(0,0,canvas.width/DPR,canvas.height/DPR);ctx.fillStyle='#228B22';ctx.fillRect(0,groundY(),W(),H()-groundY());ctx.fillStyle='#f97316';ctx.fillRect(player.x,player.y,player.w,player.h);ctx.fillStyle='gold';for(let c of coinObjs)ctx.fillRect(c.x,c.y,c.w,c.h);ctx.fillStyle='#94a3b8';for(let ob of obstacles)ctx.fillRect(ob.x,ob.y,ob.w,ob.h)}
function loop(){update();draw();requestAnimationFrame(loop)}
requestAnimationFrame(loop);

function jump(){if(player.onGround){player.vy=jumpPower;player.onGround=false;playSound('flap.mp3')}}
function gameOver(){running=false;document.getElementById('msg').textContent='Game Over • Score: '+score;document.getElementById('restart').classList.remove('hidden')}

let pointerDown=false;function onDown(e){e.preventDefault();pointerDown=true;jump()}
function onUp(e){e.preventDefault();pointerDown=false}
canvas.addEventListener('touchstart',onDown,{passive:false});canvas.addEventListener('touchend',onUp,{passive:false});canvas.addEventListener('mousedown',onDown);canvas.addEventListener('mouseup',onUp);window.addEventListener('keydown',(e)=>{if(e.code==='Space')jump()})

document.getElementById('restart').addEventListener('click',()=>{reset()})

// Shop logic
document.getElementById('shop').addEventListener('click',()=>{document.getElementById('shop-menu').classList.remove('hidden')})
document.getElementById('close-shop').addEventListener('click',()=>{document.getElementById('shop-menu').classList.add('hidden')})
document.querySelectorAll('.skin').forEach(el=>{el.addEventListener('click',()=>{
  let skin=el.getAttribute('data-skin');let price=skinPrices[skin]||0;if(ownedSkins[skin]){player.skin=skin;alert('Equipped '+skin)}else if(coins>=price){coins-=price;ownedSkins[skin]=true;player.skin=skin;alert('Purchased & Equipped '+skin)}else{alert('Not enough coins')}})})

function playSound(file){/* placeholder - add sound in /sounds folder */}
